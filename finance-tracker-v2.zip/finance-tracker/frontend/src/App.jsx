import React, { useState, useEffect, createContext, useContext } from "react";
import Dashboard from "./components/Dashboard.jsx";
import AddTransaction from "./components/AddTransaction.jsx";
import Budget from "./components/Budget.jsx";
import AIAnalysis from "./components/AIAnalysis.jsx";
import Goals from "./components/Goals.jsx";
import Recurring from "./components/Recurring.jsx";
import MonthlyComparison from "./components/MonthlyComparison.jsx";
import Splits from "./components/Splits.jsx";

export const ThemeCtx = createContext();
export function useTheme() { return useContext(ThemeCtx); }

const TABS = [
  { id:"dashboard",  label:"Dashboard" },
  { id:"add",        label:"Add expense" },
  { id:"budget",     label:"Budget" },
  { id:"goals",      label:"Goals" },
  { id:"recurring",  label:"Recurring" },
  { id:"monthly",    label:"Monthly" },
  { id:"splits",     label:"Splits" },
  { id:"ai",         label:"AI analysis" },
];

export default function App() {
  const [tab,          setTab]          = useState("dashboard");
  const [transactions, setTransactions] = useState([]);
  const [budgets,      setBudgets]      = useState({});
  const [summary,      setSummary]      = useState(null);
  const [loading,      setLoading]      = useState(true);
  const [dark,         setDark]         = useState(() => localStorage.getItem("theme") === "dark");

  useEffect(() => {
    document.body.style.background = dark ? "#0f0f0f" : "#f5f5f5";
    document.body.style.color      = dark ? "#e5e5e5" : "#111";
    localStorage.setItem("theme", dark ? "dark" : "light");
  }, [dark]);

  async function fetchAll() {
    setLoading(true);
    const [txRes, bdRes, smRes] = await Promise.all([
      fetch("/api/transactions"),
      fetch("/api/budgets"),
      fetch("/api/summary"),
    ]);
    setTransactions(await txRes.json());
    setBudgets(await bdRes.json());
    setSummary(await smRes.json());
    setLoading(false);
  }

  useEffect(() => { fetchAll(); }, []);

  async function addTransaction(data) {
    await fetch("/api/transactions", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    fetchAll();
  }

  async function deleteTransaction(id) {
    await fetch(`/api/transactions/${id}`, { method: "DELETE" });
    fetchAll();
  }

  async function saveBudgets(data) {
    await fetch("/api/budgets", {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    });
    fetchAll();
  }

  function exportCSV() {
    window.open("/api/export/csv", "_blank");
  }

  const bg    = dark ? "#0f0f0f" : "#f5f5f5";
  const hdrBg = dark ? "#1a1a1a" : "#fff";
  const bdr   = dark ? "#2a2a2a" : "#e5e5e5";
  const text  = dark ? "#e5e5e5" : "#111";
  const sub   = dark ? "#999"    : "#888";

  return (
    <ThemeCtx.Provider value={{ dark }}>
      <div style={{ minHeight: "100vh", background: bg, color: text }}>
        <header style={{ background: hdrBg, borderBottom: `1px solid ${bdr}`, padding: "1rem 1.5rem 0", position: "sticky", top: 0, zIndex: 100 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: "0.75rem" }}>
            <div>
              <h1 style={{ fontSize: "1.2rem", fontWeight: 700, color: text }}>💰 Finance Tracker</h1>
              <p style={{ fontSize: "0.72rem", color: sub, marginTop: 2 }}>AI-powered expense analysis</p>
            </div>
            <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
              <button onClick={exportCSV} style={outlineBtn(dark)} title="Export CSV">⬇ Export</button>
              <button onClick={() => setDark(d => !d)} style={outlineBtn(dark)} title="Toggle theme">
                {dark ? "☀ Light" : "🌙 Dark"}
              </button>
              <span style={{ fontSize: "0.72rem", color: sub }}>
                {new Date().toLocaleDateString("en-IN", { month: "long", year: "numeric" })}
              </span>
            </div>
          </div>
          <nav style={{ display: "flex", gap: 0, overflowX: "auto" }}>
            {TABS.map(t => (
              <button key={t.id}
                style={{
                  padding: "0.55rem 0.9rem", fontSize: "0.78rem", fontWeight: 500,
                  background: "none", border: "none", cursor: "pointer", whiteSpace: "nowrap",
                  borderBottom: tab === t.id ? `2px solid ${dark?"#fff":"#111"}` : "2px solid transparent",
                  color: tab === t.id ? text : sub,
                }}
                onClick={() => setTab(t.id)}
              >{t.label}</button>
            ))}
          </nav>
        </header>

        <main style={{ maxWidth: 960, margin: "0 auto", padding: "1.5rem" }}>
          {loading ? (
            <div style={{ textAlign: "center", padding: "3rem", color: sub }}>Loading...</div>
          ) : (
            <>
              {tab === "dashboard"  && <Dashboard transactions={transactions} summary={summary} budgets={budgets} onDelete={deleteTransaction} dark={dark} />}
              {tab === "add"        && <AddTransaction transactions={transactions} onAdd={addTransaction} onDelete={deleteTransaction} dark={dark} />}
              {tab === "budget"     && <Budget budgets={budgets} summary={summary} onSave={saveBudgets} dark={dark} />}
              {tab === "goals"      && <Goals dark={dark} />}
              {tab === "recurring"  && <Recurring dark={dark} />}
              {tab === "monthly"    && <MonthlyComparison dark={dark} />}
              {tab === "splits"     && <Splits dark={dark} />}
              {tab === "ai"         && <AIAnalysis transactions={transactions} summary={summary} budgets={budgets} dark={dark} />}
            </>
          )}
        </main>
      </div>
    </ThemeCtx.Provider>
  );
}

function outlineBtn(dark) {
  return {
    padding: "5px 12px", fontSize: 12, fontWeight: 500, cursor: "pointer",
    background: "none", borderRadius: 8,
    border: `1px solid ${dark ? "#444" : "#ccc"}`,
    color: dark ? "#ccc" : "#555",
  };
}
