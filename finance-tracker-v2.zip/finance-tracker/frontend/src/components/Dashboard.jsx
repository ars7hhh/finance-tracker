import React, { useState } from "react";
import { PieChart, Pie, Cell, Tooltip, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid } from "recharts";
import { CATS, COLORS, ICONS, fmt, t, Panel, PanelTitle, TxnRow } from "./theme.jsx";

export default function Dashboard({ transactions, summary, budgets, onDelete, dark }) {
  const c = t(dark);
  const [search,   setSearch]   = useState("");
  const [filterCat, setFilter]  = useState("All");

  if (!summary) return null;
  const { total_expenses, total_income, balance, cat_totals, daily, forecast, last_month } = summary;

  const pieData = Object.entries(cat_totals).filter(([,v])=>v>0).map(([name,value])=>({name,value}));

  const last7 = [];
  for (let i = 6; i >= 0; i--) {
    const d = new Date(); d.setDate(d.getDate()-i);
    const key = d.toISOString().split("T")[0];
    last7.push({ date: key.slice(5), amount: daily[key]||0 });
  }

  const expDiff = total_expenses - (last_month?.expenses||0);
  const expDiffPct = last_month?.expenses ? Math.round((expDiff/last_month.expenses)*100) : 0;

  const filtered = [...transactions]
    .filter(tx => filterCat === "All" || tx.cat === filterCat)
    .filter(tx => tx.desc.toLowerCase().includes(search.toLowerCase()) || tx.cat.toLowerCase().includes(search.toLowerCase()))
    .reverse()
    .slice(0, 30);

  return (
    <div>
      {/* metrics */}
      <div style={{ display:"grid", gridTemplateColumns:"repeat(4,1fr)", gap:10, marginBottom:14 }}>
        {[
          { label:"Total spent",   value:fmt(total_expenses), sub:"This month" },
          { label:"Income",        value:fmt(total_income),   sub:"This month" },
          { label:"Balance",       value:fmt(Math.abs(balance)), sub: balance>=0?"Saved":"Deficit", color: balance>=0?"#1D9E75":"#E24B4A" },
          { label:"Month forecast",value:fmt(forecast), sub:"At current rate", color: forecast>total_income?"#E24B4A":"#BA7517" },
        ].map(m => (
          <div key={m.label} style={{ background:c.panel, border:`1px solid ${c.bdr}`, borderRadius:10, padding:"12px 14px" }}>
            <div style={{ fontSize:11, color:c.sub, marginBottom:4 }}>{m.label}</div>
            <div style={{ fontSize:20, fontWeight:700, color:m.color||c.text }}>{m.value}</div>
            <div style={{ fontSize:11, color:c.sub, marginTop:2 }}>{m.sub}</div>
          </div>
        ))}
      </div>

      {/* vs last month banner */}
      {last_month?.expenses > 0 && (
        <div style={{ background: expDiff>0?"#fff7ed":"#f0fdf4", border:`1px solid ${expDiff>0?"#fed7aa":"#bbf7d0"}`, borderRadius:10, padding:"10px 14px", marginBottom:14, fontSize:13, color: expDiff>0?"#92400e":"#166534" }}>
          {expDiff>0 ? "📈" : "📉"} vs last month: <strong>{expDiff>0?"+":""}{fmt(expDiff)}</strong> ({expDiff>0?"+":""}{expDiffPct}%) — spending is {expDiff>0?"higher":"lower"} than last month
        </div>
      )}

      {/* charts */}
      <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:12, marginBottom:14 }}>
        <Panel dark={dark}>
          <PanelTitle dark={dark}>By category</PanelTitle>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={pieData} cx="50%" cy="50%" innerRadius={45} outerRadius={75} dataKey="value">
                {pieData.map((e,i)=><Cell key={e.name} fill={COLORS[CATS.indexOf(e.name)]} />)}
              </Pie>
              <Tooltip formatter={v=>fmt(v)} contentStyle={{ background:c.panel, border:`1px solid ${c.bdr}`, color:c.text, fontSize:12 }} />
            </PieChart>
          </ResponsiveContainer>
          <div style={{ display:"flex", flexWrap:"wrap", gap:8, marginTop:4 }}>
            {pieData.map(d=>(
              <span key={d.name} style={{ display:"flex", alignItems:"center", gap:4, fontSize:11, color:c.sub }}>
                <span style={{ width:8, height:8, borderRadius:2, background:COLORS[CATS.indexOf(d.name)], display:"inline-block" }}/>
                {d.name}
              </span>
            ))}
          </div>
        </Panel>
        <Panel dark={dark}>
          <PanelTitle dark={dark}>Daily spending (last 7 days)</PanelTitle>
          <ResponsiveContainer width="100%" height={200}>
            <BarChart data={last7} margin={{ top:4, right:8, left:-10, bottom:0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke={dark?"#2a2a2a":"#f0f0f0"} />
              <XAxis dataKey="date" tick={{ fontSize:10, fill:c.sub }} />
              <YAxis tick={{ fontSize:10, fill:c.sub }} tickFormatter={v=>`₹${v}`} />
              <Tooltip formatter={v=>fmt(v)} contentStyle={{ background:c.panel, border:`1px solid ${c.bdr}`, color:c.text, fontSize:12 }} />
              <Bar dataKey="amount" fill="#378ADD" radius={[3,3,0,0]} />
            </BarChart>
          </ResponsiveContainer>
        </Panel>
      </div>

      {/* search & filter */}
      <Panel dark={dark}>
        <PanelTitle dark={dark}>Transactions</PanelTitle>
        <div style={{ display:"flex", gap:8, marginBottom:12 }}>
          <input
            style={{ flex:1, padding:"7px 10px", fontSize:13, border:`1px solid ${c.inpBdr}`, borderRadius:8, background:c.inp, color:c.text, fontFamily:"inherit", outline:"none" }}
            placeholder="🔍 Search transactions..."
            value={search} onChange={e=>setSearch(e.target.value)}
          />
          <select
            style={{ padding:"7px 10px", fontSize:13, border:`1px solid ${c.inpBdr}`, borderRadius:8, background:c.inp, color:c.text, fontFamily:"inherit", outline:"none" }}
            value={filterCat} onChange={e=>setFilter(e.target.value)}
          >
            <option value="All">All categories</option>
            {CATS.map(c=><option key={c}>{c}</option>)}
          </select>
        </div>
        {filtered.length===0 && <div style={{ textAlign:"center", padding:"1.5rem", color:c.sub, fontSize:13 }}>No transactions found</div>}
        {filtered.map(tx=><TxnRow key={tx.id} t={tx} onDelete={onDelete} dark={dark} />)}
      </Panel>
    </div>
  );
}
