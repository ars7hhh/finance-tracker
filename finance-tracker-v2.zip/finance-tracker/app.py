from flask import Flask, jsonify, request, send_from_directory, Response
from flask_cors import CORS
import csv, os, json, re
from datetime import datetime, timedelta
from collections import defaultdict
import requests as http_requests

app = Flask(__name__, static_folder="frontend/dist", static_url_path="")
CORS(app)

DATA_FILE      = "data/transactions.csv"
BUDGET_FILE    = "data/budgets.json"
GOALS_FILE     = "data/goals.json"
SPLITS_FILE    = "data/splits.json"
FIELDNAMES     = ["id", "desc", "amount", "type", "cat", "date", "recurring"]

OLLAMA_URL   = os.environ.get("OLLAMA_URL",   "http://localhost:11434")
OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "llama3")

# ── ollama ────────────────────────────────────────────────────────────────────

def ollama(prompt, max_tokens=400):
    try:
        r = http_requests.post(
            f"{OLLAMA_URL}/api/generate",
            json={"model": OLLAMA_MODEL, "prompt": prompt,
                  "stream": False, "options": {"num_predict": max_tokens}},
            timeout=60,
        )
        return r.json().get("response", "").strip()
    except Exception as e:
        return f"Ollama error: {e}"

# ── file helpers ──────────────────────────────────────────────────────────────

def ensure_files():
    os.makedirs("data", exist_ok=True)
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=FIELDNAMES)
            w.writeheader()
            seed = [
                {"id":1,  "desc":"Zomato dinner",   "amount":450,   "type":"expense","cat":"Food",          "date":"2026-04-18","recurring":""},
                {"id":2,  "desc":"Uber to office",   "amount":120,   "type":"expense","cat":"Transport",     "date":"2026-04-19","recurring":""},
                {"id":3,  "desc":"Electricity bill", "amount":1800,  "type":"expense","cat":"Bills",         "date":"2026-04-15","recurring":"monthly"},
                {"id":4,  "desc":"Amazon purchase",  "amount":2200,  "type":"expense","cat":"Shopping",      "date":"2026-04-14","recurring":""},
                {"id":5,  "desc":"Salary",           "amount":55000, "type":"income", "cat":"Other",         "date":"2026-04-01","recurring":"monthly"},
                {"id":6,  "desc":"Swiggy lunch",     "amount":380,   "type":"expense","cat":"Food",          "date":"2026-04-20","recurring":""},
                {"id":7,  "desc":"Metro card",       "amount":200,   "type":"expense","cat":"Transport",     "date":"2026-04-17","recurring":""},
                {"id":8,  "desc":"Movie tickets",    "amount":600,   "type":"expense","cat":"Entertainment", "date":"2026-04-21","recurring":""},
                {"id":9,  "desc":"Pharmacy",         "amount":340,   "type":"expense","cat":"Health",        "date":"2026-04-16","recurring":""},
                {"id":10, "desc":"Grocery store",    "amount":1200,  "type":"expense","cat":"Food",          "date":"2026-04-22","recurring":""},
                {"id":11, "desc":"Netflix",          "amount":649,   "type":"expense","cat":"Entertainment", "date":"2026-04-05","recurring":"monthly"},
                {"id":12, "desc":"Gym membership",   "amount":1200,  "type":"expense","cat":"Health",        "date":"2026-04-03","recurring":"monthly"},
                {"id":13, "desc":"Petrol",           "amount":1500,  "type":"expense","cat":"Transport",     "date":"2026-04-10","recurring":""},
                {"id":14, "desc":"Rent",             "amount":12000, "type":"expense","cat":"Bills",         "date":"2026-04-01","recurring":"monthly"},
            ]
            w.writerows(seed)

    for fpath, default in [
        (BUDGET_FILE, {"Food":3000,"Transport":1500,"Bills":15000,"Shopping":3000,"Health":2000,"Entertainment":2000,"Other":1000}),
        (GOALS_FILE,  []),
        (SPLITS_FILE, []),
    ]:
        if not os.path.exists(fpath):
            with open(fpath, "w") as f:
                json.dump(default, f)

def read_transactions():
    with open(DATA_FILE, newline="") as f:
        rows = list(csv.DictReader(f))
    for r in rows:
        r["amount"]    = float(r["amount"])
        r["recurring"] = r.get("recurring", "")
    return rows

def write_transactions(rows):
    with open(DATA_FILE, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDNAMES)
        w.writeheader()
        w.writerows(rows)

def next_id(rows):
    return max((int(r["id"]) for r in rows), default=0) + 1

def rj(path):
    with open(path) as f: return json.load(f)

def wj(path, data):
    with open(path, "w") as f: json.dump(data, f, indent=2)

# ── transactions ──────────────────────────────────────────────────────────────

@app.route("/api/transactions", methods=["GET"])
def get_transactions():
    return jsonify(read_transactions())

@app.route("/api/transactions", methods=["POST"])
def add_transaction():
    d    = request.json
    rows = read_transactions()
    row  = {
        "id":        next_id(rows),
        "desc":      d["desc"],
        "amount":    float(d["amount"]),
        "type":      d["type"],
        "cat":       d.get("cat", "Other"),
        "date":      d.get("date", datetime.today().strftime("%Y-%m-%d")),
        "recurring": d.get("recurring", ""),
    }
    rows.append(row)
    write_transactions(rows)
    return jsonify(row), 201

@app.route("/api/transactions/<int:tid>", methods=["DELETE"])
def delete_transaction(tid):
    rows = [r for r in read_transactions() if int(r["id"]) != tid]
    write_transactions(rows)
    return jsonify({"deleted": tid})

# ── budgets ───────────────────────────────────────────────────────────────────

@app.route("/api/budgets", methods=["GET"])
def get_budgets():  return jsonify(rj(BUDGET_FILE))

@app.route("/api/budgets", methods=["POST"])
def save_budgets(): wj(BUDGET_FILE, request.json); return jsonify({"status": "saved"})

# ── summary ───────────────────────────────────────────────────────────────────

@app.route("/api/summary", methods=["GET"])
def get_summary():
    rows    = read_transactions()
    exp     = [r for r in rows if r["type"] == "expense"]
    inc     = [r for r in rows if r["type"] == "income"]
    tot_exp = sum(r["amount"] for r in exp)
    tot_inc = sum(r["amount"] for r in inc)

    cat_totals = defaultdict(float)
    for r in exp: cat_totals[r["cat"]] += r["amount"]

    daily = defaultdict(float)
    for r in exp: daily[r["date"]] += r["amount"]

    today     = datetime.today()
    days_gone = max(today.day, 1)
    forecast  = round((tot_exp / days_gone) * 30, 2)

    last_ym   = (today.replace(day=1) - timedelta(days=1)).strftime("%Y-%m")
    last_exp  = sum(r["amount"] for r in exp if r["date"].startswith(last_ym))
    last_inc  = sum(r["amount"] for r in inc if r["date"].startswith(last_ym))

    return jsonify({
        "total_expenses": tot_exp,
        "total_income":   tot_inc,
        "balance":        tot_inc - tot_exp,
        "cat_totals":     dict(cat_totals),
        "daily":          dict(daily),
        "forecast":       forecast,
        "last_month":     {"expenses": last_exp, "income": last_inc},
    })

# ── export ────────────────────────────────────────────────────────────────────

@app.route("/api/export/csv", methods=["GET"])
def export_csv():
    rows = read_transactions()
    def gen():
        yield "id,date,description,amount,type,category,recurring\n"
        for r in rows:
            yield f"{r['id']},{r['date']},\"{r['desc']}\",{r['amount']},{r['type']},{r['cat']},{r['recurring']}\n"
    return Response(gen(), mimetype="text/csv",
                    headers={"Content-Disposition": "attachment;filename=transactions.csv"})

# ── goals ─────────────────────────────────────────────────────────────────────

@app.route("/api/goals", methods=["GET"])
def get_goals(): return jsonify(rj(GOALS_FILE))

@app.route("/api/goals", methods=["POST"])
def add_goal():
    goals = rj(GOALS_FILE)
    g = request.json
    g["id"]      = max((x["id"] for x in goals), default=0) + 1
    g["saved"]   = float(g.get("saved", 0))
    g["target"]  = float(g["target"])
    g["created"] = datetime.today().strftime("%Y-%m-%d")
    goals.append(g)
    wj(GOALS_FILE, goals)
    return jsonify(g), 201

@app.route("/api/goals/<int:gid>", methods=["PUT"])
def update_goal(gid):
    goals = rj(GOALS_FILE)
    for g in goals:
        if g["id"] == gid: g.update(request.json)
    wj(GOALS_FILE, goals)
    return jsonify({"status": "updated"})

@app.route("/api/goals/<int:gid>", methods=["DELETE"])
def delete_goal(gid):
    wj(GOALS_FILE, [g for g in rj(GOALS_FILE) if g["id"] != gid])
    return jsonify({"deleted": gid})

# ── recurring / reminders ─────────────────────────────────────────────────────

@app.route("/api/recurring", methods=["GET"])
def get_recurring():
    return jsonify([r for r in read_transactions() if r.get("recurring")])

@app.route("/api/reminders", methods=["GET"])
def get_reminders():
    rows  = read_transactions()
    today = datetime.today()
    seen  = {}
    for r in rows:
        if r.get("recurring") == "monthly" and r["desc"] not in seen:
            seen[r["desc"]] = r
    out = []
    for desc, r in seen.items():
        last   = datetime.strptime(r["date"], "%Y-%m-%d")
        day    = last.day
        if today.day >= day:
            nm = today.month % 12 + 1
            ny = today.year + (1 if nm == 1 else 0)
        else:
            nm, ny = today.month, today.year
        try:
            next_due = today.replace(year=ny, month=nm, day=day)
        except:
            next_due = today
        days_left = (next_due - today).days
        out.append({"desc": desc, "amount": r["amount"], "cat": r["cat"],
                    "next_due": next_due.strftime("%Y-%m-%d"),
                    "days_left": days_left, "overdue": days_left < 0})
    out.sort(key=lambda x: x["days_left"])
    return jsonify(out)

# ── monthly comparison ────────────────────────────────────────────────────────

@app.route("/api/monthly", methods=["GET"])
def get_monthly():
    rows    = read_transactions()
    monthly = defaultdict(lambda: {"expenses": 0, "income": 0, "cats": defaultdict(float)})
    for r in rows:
        ym = r["date"][:7]
        if r["type"] == "expense":
            monthly[ym]["expenses"]      += r["amount"]
            monthly[ym]["cats"][r["cat"]] += r["amount"]
        else:
            monthly[ym]["income"] += r["amount"]
    result = []
    for ym in sorted(monthly)[-6:]:
        result.append({"month": ym, "expenses": round(monthly[ym]["expenses"],2),
                       "income": round(monthly[ym]["income"],2), "cats": dict(monthly[ym]["cats"])})
    return jsonify(result)

# ── splits ────────────────────────────────────────────────────────────────────

@app.route("/api/splits", methods=["GET"])
def get_splits(): return jsonify(rj(SPLITS_FILE))

@app.route("/api/splits", methods=["POST"])
def add_split():
    splits = rj(SPLITS_FILE)
    s = request.json
    s["id"]      = max((x["id"] for x in splits), default=0) + 1
    s["date"]    = s.get("date", datetime.today().strftime("%Y-%m-%d"))
    s["settled"] = False
    s["amount"]  = float(s["amount"])
    splits.append(s)
    wj(SPLITS_FILE, splits)
    return jsonify(s), 201

@app.route("/api/splits/<int:sid>/settle", methods=["PUT"])
def settle_split(sid):
    splits = rj(SPLITS_FILE)
    for s in splits:
        if s["id"] == sid: s["settled"] = True
    wj(SPLITS_FILE, splits)
    return jsonify({"status": "settled"})

@app.route("/api/splits/<int:sid>", methods=["DELETE"])
def delete_split(sid):
    wj(SPLITS_FILE, [s for s in rj(SPLITS_FILE) if s["id"] != sid])
    return jsonify({"deleted": sid})

# ── AI (Ollama) ───────────────────────────────────────────────────────────────

@app.route("/api/ai/categorize", methods=["POST"])
def ai_categorize():
    desc  = request.json.get("desc", "")
    CATS  = ["Food","Transport","Bills","Shopping","Health","Entertainment","Other"]
    result = ollama(
        f'Classify this expense into one of: Food, Transport, Bills, Shopping, Health, Entertainment, Other.\nExpense: "{desc}"\nRespond with ONLY the category name.',
        15
    )
    cat = result.strip().split("\n")[0].split()[0] if result else "Other"
    return jsonify({"cat": cat if cat in CATS else "Other"})

@app.route("/api/ai/analyze", methods=["POST"])
def ai_analyze():
    d = request.json
    r = ollama(f"""Analyze these monthly finances. Give exactly 3 insights and 3 actionable recommendations with specific numbers.

Income: ₹{d['total_income']:,.0f} | Expenses: ₹{d['total_expenses']:,.0f}
Categories: {json.dumps(d['cat_totals'])}
Budgets: {json.dumps(d['budgets'])}

INSIGHTS:
1.
2.
3.
RECOMMENDATIONS:
1.
2.
3.""", 500)
    return jsonify({"result": r})

@app.route("/api/ai/anomalies", methods=["POST"])
def ai_anomalies():
    d    = request.json
    txts = "\n".join(f"{t['date']}: {t['desc']} ₹{t['amount']} ({t['cat']})"
                     for t in d["transactions"] if t["type"] == "expense")
    r = ollama(f"Review transactions, flag anomalies. Under 120 words.\n\n{txts}\n\nBudgets: {json.dumps(d['budgets'])}", 250)
    return jsonify({"result": r})

@app.route("/api/ai/ask", methods=["POST"])
def ai_ask():
    d = request.json
    r = ollama(
        f"Financial context: expenses ₹{d['total_expenses']:,.0f}, breakdown: {json.dumps(d['cat_totals'])}, budgets: {json.dumps(d['budgets'])}\n\nQ: {d['question']}\n\nAnswer in 2-3 sentences with specific advice.",
        300
    )
    return jsonify({"result": r})

@app.route("/api/ai/sms-parse", methods=["POST"])
def ai_sms_parse():
    sms    = request.json.get("sms", "")
    today  = datetime.today().strftime("%Y-%m-%d")
    result = ollama(
        f'''Extract transaction from this bank SMS. Return ONLY a JSON object, no extra text.
SMS: "{sms}"
Return: {{"amount":0,"desc":"","cat":"Other","type":"expense","date":"{today}"}}
Categories: Food,Transport,Bills,Shopping,Health,Entertainment,Other. If credit/cashback use type "income".''',
        120
    )
    try:
        m = re.search(r'\{.*\}', result, re.DOTALL)
        if m: return jsonify(json.loads(m.group()))
    except: pass
    am = re.search(r'(?:INR|Rs\.?|₹)\s*([\d,]+\.?\d*)', sms, re.IGNORECASE)
    return jsonify({"amount": float(am.group(1).replace(",","")) if am else 0,
                    "desc": "UPI Payment", "cat": "Other", "type": "expense", "date": today})

# ── serve React ───────────────────────────────────────────────────────────────

@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve_react(path):
    dist = app.static_folder
    if path and os.path.exists(os.path.join(dist, path)):
        return send_from_directory(dist, path)
    return send_from_directory(dist, "index.html")

if __name__ == "__main__":
    ensure_files()
    print("🚀 Finance Tracker → http://localhost:5000")
    app.run(debug=True, port=5000)
